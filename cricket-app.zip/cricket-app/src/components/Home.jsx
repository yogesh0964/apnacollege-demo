import React from 'react';
import './Home.css'; // Import the CSS file

export default function Home() {
  return (
    <div className="homepage">
      <div className="overlay"></div>

      <div className="content">
        <h1 className="home-heading">Welcome to Indian Premier League </h1>
        <p className="home-subtext">
          Stay up-to-date with live scores, team stats, fixtures and all your cricket needs!
        </p>

        <div className="cards">
          <div className="card">
            <h3>🏏 <a href="/Matches" className="card-link">Live Matches</a></h3>
            <p>Get real-time scores and match updates.</p>
          </div>
          <div className="card">
            <h3>🌍 <a href="/teams" className="card-link">Teams</a></h3>
            <p>Explore team profiles and player stats.</p>
          </div>
          <div className="card">
            <h3>📊 <a href="/stats" className="card-link">Stats</a></h3>
            <p>Full match statistics and performance data.</p>
          </div>
        </div>

        <div className="video-section">
          <video className="explore-video" autoPlay loop muted>
            <source src="/assets/matches.mp4" type="video/mp4" />
            Your browser does not support the video tag.
          </video>
        </div>

        <button className="cta-button">Explore Matches →</button>
      </div>
    </div>
  );
}
