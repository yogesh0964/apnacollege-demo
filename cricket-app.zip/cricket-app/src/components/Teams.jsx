import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Teams.css';
import teams from './teamData';

export default function Teams() {
  const navigate = useNavigate();

  const handleTeamClick = (team) => {
    navigate(`/teams/${encodeURIComponent(team)}`);
  };

  return (
    <div className="teams-page">
      <div className="overlay"></div>

      <div className="teams-content">
        <h1 className="teams-heading">IPL Teams</h1>
        <div className="teams-grid">
          {teams.map((team, index) => (
            <div
              key={index}
              className="team-card"
              onClick={() => handleTeamClick(team)}
            >
              {team}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
