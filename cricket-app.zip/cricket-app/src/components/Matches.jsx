import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Matches.css';
import teams from './teamData';

export default function Matches() {
  const navigate = useNavigate();
  const matches = [];

  // Generate 70 matches dynamically
  for (let i = 0; i < 70; i++) {
    const teamA = teams[i % teams.length];
    const teamB = teams[(i + 1) % teams.length];
    matches.push({ teamA, teamB });
  }

  const handleMatchClick = (teamA, teamB) => {
    navigate(`/matches/${encodeURIComponent(teamA)}-vs-${encodeURIComponent(teamB)}`);
  };

  return (
    <div className="matches-page">
      <h1 className="text-4xl font-bold text-center text-yellow-400 mb-10 relative z-10">
        IPL Matches
      </h1>

      <div className="matches-content">
        {matches.map((match, index) => (
          <div
            key={index}
            className="match-card"
            onClick={() => handleMatchClick(match.teamA, match.teamB)}
          >
            {match.teamA} <span className="text-yellow-500">vs</span> {match.teamB}
          </div>
        ))}
      </div>
    </div>
  );
}
