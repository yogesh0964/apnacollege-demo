import React from 'react';
import './Navbar.css';

const Navbar = () => {
  return (
    <nav className="navbar">
      <div className="navbar-logo">CricketPro</div>
      <ul className="navbar-links">
        <li><a href="/">Home</a></li>
        <li><a href="teams">Teams</a></li>
        <li><a href="/matches">Matches</a></li>
        <li><a href="/stats">Stats</a></li>
        <li><a href="/contact">Contact</a></li>
      </ul>
    </nav>
  );
};

export default Navbar;
