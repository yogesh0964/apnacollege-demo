import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import playersData from './playersData';
import './Teams.css';

export default function TeamDetails() {
  const { teamName } = useParams(); // Get the team name from the URL
  const players = playersData[teamName] || [];

  const [selectedPlayer, setSelectedPlayer] = useState(null);

  const handlePlayerClick = (player) => {
    setSelectedPlayer(player);
  };

  const getPlayerImagePath = (player) => {
    const basePath = `/assets/players/${player.replace(/\s+/g, '-').toLowerCase()}`;
    const extensions = ['.jpg', '.jpeg', '.avif'];
    for (const ext of extensions) {
      const path = `${basePath}${ext}`;
      console.log(`Checking path: ${path}`); // Debugging log
      const img = new Image();
      img.src = path;
      if (img.complete) {
        return path;
      }
    }
    return '/assets/placeholder.jpg'; // Fallback image
  };

  return (
    <div className="teams-page">
      <div className="overlay"></div>

      <div className="teams-content">
        <h1 className="teams-heading">{teamName}</h1>
        <div className="teams-grid">
          {players.map((player, index) => (
            <div
              key={index}
              className="team-card"
              onClick={() => handlePlayerClick(player)}
            >
              {player}
            </div>
          ))}
        </div>

        {selectedPlayer && (
          <div className="player-photo">
            <h2>{selectedPlayer}</h2>
            <a
              href={getPlayerImagePath(selectedPlayer)}
              target="_blank"
              rel="noopener noreferrer"
            >
              <img
                src={getPlayerImagePath(selectedPlayer)}
                alt={selectedPlayer}
                className="player-image"
                onError={(e) => {
                  console.error('Image not found:', e.target.src);
                  e.target.src = '/assets/placeholder.jpg'; // Fallback image
                }}
              />
            </a>
          </div>
        )}
      </div>
    </div>
  );
}