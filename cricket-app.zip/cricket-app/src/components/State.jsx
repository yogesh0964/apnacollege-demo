import React from 'react';
import { useNavigate } from 'react-router-dom';
import './State.css';

const statesWithIPLTeams = {
  "Karnataka": ["Royal Challengers Bengaluru"],
  "Tamil Nadu": ["Chennai Super Kings (CSK)"],
  "Maharashtra": ["Mumbai Indians (MI)", "Pune Warriors"],
  "West Bengal": ["Kolkata Knight Riders (KKR)"],
  "Rajasthan": ["Rajasthan Royals (RR)"],
  "Telangana": ["Sunrisers Hyderabad (SRH)"],
  "Delhi": ["Delhi Capitals (DC)"],
  "Punjab": ["Punjab Kings (PBKS)"],
  "Uttar Pradesh": ["Lucknow Super Giants (LSG)"],
  "Gujarat": ["Gujarat Titans (GT)"]
};

export default function State() {
  const navigate = useNavigate();

  const handleStateClick = (state) => {
    navigate(`/state/${encodeURIComponent(state)}`); // Navigate to state-specific page
  };

  return (
    <div className="state-page">
      <div className="overlay"></div>

      <h1 className="state-heading">States with IPL Teams</h1>

      <div className="state-grid">
        {Object.keys(statesWithIPLTeams).map((state, idx) => (
          <div
            key={idx}
            className="state-card"
            onClick={() => handleStateClick(state)}
          >
            📍 {state}
          </div>
        ))}
      </div>
    </div>
  );
}
