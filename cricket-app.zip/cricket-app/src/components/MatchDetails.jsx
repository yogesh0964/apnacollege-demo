import { useParams } from 'react-router-dom';
import playersData from './playersData';

export default function MatchDetails() {
  const { match } = useParams(); // Extract match details from URL
  const [teamA, teamB] = match.split('-vs-'); // Split the match string into two teams

  const teamAPlayers = playersData[teamA] || [];
  const teamBPlayers = playersData[teamB] || [];

  return (
    <div className="matches-page">
      <h1 className="text-4xl font-bold text-center text-yellow-400 mb-10 relative z-10">
        {teamA} <span className="text-yellow-500">vs</span> {teamB}
      </h1>

      <div className="teams-players">
        <div className="team-players">
          <h2 className="text-2xl font-bold text-center mb-4">{teamA} Players</h2>
          <ul>
            {teamAPlayers.map((player, index) => (
              <li key={index}>{player}</li>
            ))}
          </ul>
        </div>

        <div className="team-players">
          <h2 className="text-2xl font-bold text-center mb-4">{teamB} Players</h2>
          <ul>
            {teamBPlayers.map((player, index) => (
              <li key={index}>{player}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}