// Shared team data for both Teams and Matches components
const teams = [
  'Royal Challengers Bengaluru',
  'Chennai Super Kings (CSK)',
  'Mumbai Indians (MI)',
  'Kolkata Knight Riders (KKR)',
  'Rajasthan Royals (RR)',
  'Sunrisers Hyderabad (SRH)',
  'Delhi Capitals (DC)',
  'Punjab Kings (PBKS)',
  'Lucknow Super Giants (LSG)',
  'Gujarat Titans (GT)'
];

export default teams;