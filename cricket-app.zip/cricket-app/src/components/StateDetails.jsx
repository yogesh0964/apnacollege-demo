import React from 'react';
import { useParams } from 'react-router-dom';
import './State.css';

const statesWithIPLTeams = {
  "Karnataka": ["Royal Challengers Bengaluru"],
  "Tamil Nadu": ["Chennai Super Kings (CSK)"],
  "Maharashtra": ["Mumbai Indians (MI)", "Pune Warriors"],
  "West Bengal": ["Kolkata Knight Riders (KKR)"],
  "Rajasthan": ["Rajasthan Royals (RR)"],
  "Telangana": ["Sunrisers Hyderabad (SRH)"],
  "Delhi": ["Delhi Capitals (DC)"],
  "Punjab": ["Punjab Kings (PBKS)"],
  "Uttar Pradesh": ["Lucknow Super Giants (LSG)"],
  "Gujarat": ["Gujarat Titans (GT)"]
};

export default function StateDetails() {
  const { stateName } = useParams(); // Get the state name from the URL
  const teams = statesWithIPLTeams[stateName] || [];

  return (
    <div className="state-page">
      <div className="overlay"></div>

      <h1 className="state-heading">{stateName}</h1>

      <div className="state-grid">
        {teams.length > 0 ? (
          teams.map((team, idx) => (
            <div key={idx} className="state-card">
              🏏 {team}
            </div>
          ))
        ) : (
          <p>No IPL teams found for this state.</p>
        )}
      </div>
    </div>
  );
}