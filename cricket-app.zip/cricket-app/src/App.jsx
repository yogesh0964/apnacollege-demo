import './App.css';
import Navbar from './components/Navbar';
import Home from './components/Home';
import Teams from './components/Teams';
import Matches from './components/Matches';
import State from './components/State';
import StateDetails from './components/StateDetails';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import TeamDetails from './components/TeamDetails';
import MatchDetails from './components/MatchDetails';
import Contact from './components/Contact';

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/teams" element={<Teams />} />
        <Route path="/teams/:teamName" element={<TeamDetails />} />
        <Route path="/matches" element={<Matches />} />
        <Route path="/matches/:match" element={<MatchDetails />} />
        <Route path="/state" element={<State />} />
        <Route path="/state/:stateName" element={<StateDetails />} />
        <Route path="/contact" element={<Contact />} />
      </Routes>
    </Router>
  );
}

export default App;
